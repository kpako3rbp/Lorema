export const renderTitleIcon = (): string => /*html */ `
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
    <path d="M17 4l0 16" />
    <path d="M7 12l10 0" />
    <path d="M7 4l0 16" />
  </svg>
`;

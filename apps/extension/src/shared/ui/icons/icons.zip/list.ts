export const renderListIcon = (): string => /*html */ `
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-list-tree">
  <path stroke="none" d="M0 0h24v24H0z" fill="none" />
  <path d="M9 6h11" />
  <path d="M12 12h8" />
  <path d="M15 18h5" />
  <path d="M5 6v.01" />
  <path d="M8 12v.01" />
  <path d="M11 18v.01" />
</svg>
`;
